package business;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Product;
import database.ProductDataService;


@Stateless
@Local(ProductBusinessInterface.class)
@Alternative
public class ProductBusinessService implements ProductBusinessInterface{
	List<Product> products = new ArrayList<Product>();
	
	@EJB
	ProductDataService dbservice;
	
	public ProductBusinessService() {
	}
	
	public ProductBusinessService(List<Product> products) {
		 this.products = products;
	}
	
	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		try {
			products = dbservice.getAllProducts();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return products;
	}

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		try {
			dbservice.insertProduct(product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("**************** Successfully added new product");
	}

	@Override
	public void removeProduct(int productID) {
		// TODO Auto-generated method stub
		try {
			dbservice.removeProduct(productID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("**************** Successfully deleted product: " + productID);
	}

	@Override
	public void updateProduct(int productID, Product product) {
		try {
			dbservice.updateProduct(productID, product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		Product product = null;
		try {
			product = dbservice.getProductById(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return product;
	}
}
