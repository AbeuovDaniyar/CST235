package business;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import beans.Product;

@RequestScoped
@Path("/products")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class ProductsRestService {

	@Inject 
	ProductBusinessInterface service;
	
	//gets json data of all products in the product table in the database
	@GET
	@Path("/getjson")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getOrdersAsJson() {
		return service.getProducts();
	}
	
	//get json data of the product by id
	@GET
	@Path("/getjsonbyid/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Product getProductById(@PathParam("id") int id){
		if(id <= 0) {
			System.out.println("The id value cannot be <= 0");
		}
		return service.getProductById(id);
	}
	
	//accepts json data only!! will add a new product to the products table in the database
	@POST
	@Path("/addProduct")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
	public void addProduct(Product product){
		service.addProduct(product);
		System.out.println("===================> Successfully added new product using JAX-RS REST API" + product.getName());
	}	
}
