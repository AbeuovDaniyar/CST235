package business;

import javax.enterprise.context.RequestScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import beans.Bible;

@RequestScoped
@Path("/bible")
@Produces({ "application/xml", "application/json" })
@Consumes({ "application/xml", "application/json" })
public class BibleRestService {

	@GET
	@Path("/getjson/{search}")
	public Bible testAPI(@PathParam("{search}") String searchStr) {
		Client client = ClientBuilder.newClient();
		WebTarget myResource = client.target("https://api.esv.org/v3/passage/search/?q=" + searchStr);
		Builder builder = myResource.request(MediaType.APPLICATION_JSON);
		builder.header("Authorization", "Token 8975aaefe129ef6afaed7ed33e2edc1e61b2c060");
		Response response = builder.get(Response.class);
		
		Bible bible = response.readEntity(new GenericType<Bible>() {});
		
		System.out.println("========> Success");
		
		return bible;
	}
}
