package controllers;

import java.sql.SQLException;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Bible;
import beans.BiblePassage;
import beans.Product;
import beans.User;
import business.BibleBisunessService;
import business.ProductBusinessInterface;
import business.UsersBusinessInterface;

@ManagedBean
@ViewScoped
public class FormController {
	@Inject
	UsersBusinessInterface service;
	
	@Inject
	ProductBusinessInterface productService;

	@EJB
	BibleBisunessService bibleService;
	
public String onSubmit() {
	FacesContext context = FacesContext.getCurrentInstance();
	User user = context.getApplication().evaluateExpressionGet(context, "#{user}" , User.class);
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
	return "TestResponse.xhtml";
}

public String onSearch() {
	//BibleBisunessService bibleService = new BibleBisunessService();
	FacesContext context = FacesContext.getCurrentInstance();
	String searchStr = context.getApplication().evaluateExpressionGet(context, "#{searchStr}" , String.class);
	
	Bible bible = bibleService.getData(searchStr);
	
	System.out.println("================> onSearch method from the controller " + bible.getPage());
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("bible", bible);
	return "showTest.xhtml";
}

public String onSearchPassage() {
	FacesContext context = FacesContext.getCurrentInstance();
	String searchPassage = context.getApplication().evaluateExpressionGet(context, "#{searchPassage}" , String.class);
	
	BiblePassage biblePassage = bibleService.searchPassage(searchPassage);
	
	System.out.println("================> onSearchPassage method from the controller " + biblePassage.getCanonical());
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("biblePassage", biblePassage);
	return "biblePassage.xhtml";
}


public UsersBusinessInterface getService() {
	return service;
}

public ProductBusinessInterface getProductService() {
	return productService;
}

public String onAddProduct(Product product) throws SQLException {
	//ProductBusinessInterface productService = getProductService();
	productService.addProduct(product);
	//productDBService.insertProduct(product);

	return "displayProducts.xhtml";
}

public String onDelete(Product product) {	
	//put the get value into the response page 
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("product", product);
	System.out.println("this is onDelete() product id: " + product.getId());
	
	return "DeleteProduct.xhtml";
}


public String onEdit(Product product) {	
	//put the get value into the response page 
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("product", product);
	return "EditProductForm.xhtml";
}

public String onSubmitEdit(int id) {
	//read the get value
	FacesContext context = FacesContext.getCurrentInstance();
	
	//store the get value
	Product product = context.getApplication().evaluateExpressionGet(context, "#{product}" , Product.class);
	
	//call the update method from product business service 
	productService.updateProduct(id, product);
	
	System.out.println("successfuly edited product: " + product.getId());
	
	//put the get value into the response page 
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("product", product);
	
	return "displayProducts.xhtml";
}

public String onSubmitDelete() {
	//read the get value
	FacesContext context = FacesContext.getCurrentInstance();
	
	//store the get value
	Product product = context.getApplication().evaluateExpressionGet(context, "#{product}" , Product.class);
	
	//call the update method from product business service 
	productService.removeProduct(product.id);
	
	System.out.println("successfuly deleted product: " + product.id);
	
	//put the get value into the response page 
	FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("product", product);
	
	return "displayProducts.xhtml";
}

public String onCancelDelete() {
	return "displayProducts.xhtml";
}
}
