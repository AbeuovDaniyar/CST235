package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.Order;
import beans.Product;

/**
 * Session Bean implementation class ProductDataService
 */
@Stateless
@LocalBean
public class ProductDataService {
	private final String url = "jdbc:postgresql://localhost:5432/postgres";
	private final String username = "postgres";
	private final String password = "root";
    /**
     * Default constructor. 
     */
    public ProductDataService() {
        // TODO Auto-generated constructor stub
    }
    
    //returns database connection
    public Connection getConnection() throws SQLException 
    {
		Connection conn = null;
		
		 try {
			 	//connect to database
			 	conn = DriverManager.getConnection(url, username, password);
		        //System.out.println("Connected to the PostgreSQL server successfully.");

		    } catch (SQLException e) {
		        System.out.println(e.getMessage());
		    }
		
		return conn;
    }
    
    //insert product into products table
    public void insertProduct(Product product) throws SQLException {		
    	//get connection to db
    	Connection conn = getConnection();
		
    	PreparedStatement sql = conn.prepareStatement("INSERT INTO \"myStore\".products(\"PRODUCT_NAME\", \"DEVELOPER\", \"PUBLISHER\", \"PLATFORM\", \"DESCRIPTION\", \"PRICE\") VALUES (?, ?, ?, ?, ?, ?);");
		
    	sql.setString(1, product.getName());
    	sql.setString(2, product.getDeveloper());
    	sql.setString(3, product.getPublisher());
    	sql.setString(4, product.getPlatform());
    	sql.setString(5, product.getDescription());
    	sql.setDouble(6, product.getPrice());
    	try {			
			//exeute sql query   		
    		sql.executeUpdate();
    		sql.close();
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
	}
    
    //gets all products from product table
    public List<Product> getAllProducts() throws SQLException{
    	//get connection to db
    	Connection conn = getConnection();
    	
		//Select sql statement
    	String sql = "SELECT * FROM \"myStore\".products ORDER BY \"ID\" ASC ";
    	
		//create a list of products
    	List<Product> products = new ArrayList<Product>();
    	
    	try {
			//exeute sql query
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			//populate the list with data from the query
			while(rs.next()) {
				products.add(new Product(rs.getInt("ID"), 
										rs.getString("PRODUCT_NAME"),
										rs.getString("DEVELOPER"),
										rs.getString("PUBLISHER"),
										rs.getString("PLATFORM"),
										rs.getString("DESCRIPTION"),
										rs.getDouble("PRICE")));
			}
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		return products;
    }
    
    //delete a row from products table by id
    public void removeProduct(int id) throws SQLException{
       	//get connection to db
    	Connection conn = getConnection();
    	
		//Select sql statement
    	PreparedStatement sql = conn.prepareStatement("DELETE FROM \"myStore\".products WHERE \"ID\" IN (?);");
    	
    	sql.setInt(1, id);
    	
    	
    	try {
			//exeute sql query
    		sql.executeUpdate();
    		sql.close();
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
    }
    
    //delete a row from products table by id
    public void updateProduct(int id, Product product) throws SQLException{
       	//get connection to db
    	Connection conn = getConnection();
    	
		//update sql statement
    	PreparedStatement sql = conn.prepareStatement("UPDATE \"myStore\".products SET \"PRODUCT_NAME\"=?, \"DEVELOPER\"=?, \"PUBLISHER\"=?, \"PLATFORM\"=?, \"DESCRIPTION\"=?, \"PRICE\"=? WHERE \"ID\" IN (?);");
    	
    	sql.setString(1, product.getName());
    	sql.setString(2, product.getDeveloper());
    	sql.setString(3, product.getPublisher());
    	sql.setString(4, product.getPlatform());
    	sql.setString(5, product.getDescription());
    	sql.setDouble(6, product.getPrice());
    	sql.setInt(7, id);
    	
    	try {
			//exeute sql query
    		sql.executeUpdate();
    		sql.close();
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
    }
    

	public Product getProductById(int id) throws SQLException {
		// TODO Auto-generated method stub
		Product product = null;
		//get connection to db
    	Connection conn = getConnection();
    	
		//Select sql statement
    	PreparedStatement sql = conn.prepareStatement("SELECT * FROM \"myStore\".products WHERE \"ID\"=?;");
    	
    	sql.setInt(1, id);
    	
    	try {
			//exeute sql query
    		ResultSet rs = sql.executeQuery();
    		
    		while(rs.next()) {
    			product = new Product(rs.getInt("ID"), 
						rs.getString("PRODUCT_NAME"),
						rs.getString("DEVELOPER"),
						rs.getString("PUBLISHER"),
						rs.getString("PLATFORM"),
						rs.getString("DESCRIPTION"),
						rs.getDouble("PRICE"));	
    		}
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		return product;
	}
}
