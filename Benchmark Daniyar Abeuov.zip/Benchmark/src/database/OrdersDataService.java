package database;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class OrdersDataService
 */
@Stateless
@LocalBean
public class OrdersDataService {
	private final String url = "jdbc:postgresql://localhost:5432/postgres";
	private final String username = "postgres";
	private final String password = "root";

    /**
     * Default constructor. 
     */
    public OrdersDataService() {
        // TODO Auto-generated constructor stub
    }
    /*
    //returns database connection
    public Connection getConnection() throws SQLException 
    {
		Connection conn = null;
		
		 try {
			 	//connect to database
			 	conn = DriverManager.getConnection(url, username, password);
		        //System.out.println("Connected to the PostgreSQL server successfully.");

		    } catch (SQLException e) {
		        System.out.println(e.getMessage());
		    }
		
		return conn;
    }
    
  //insert product into products table
    public void insertProduct(Order product) throws SQLException {
		//String sql = "INSERT INTO testapp.\"Orders\"(\"ID\", \"ORDER_NO\", \"PRODUCT_NAME\", \"PRICE\", \"QUANTITY\") VALUES (12, '0000000012', 'This is Product 12', 12.00, 12)";
		
    	//get connection to db
    	Connection conn = getConnection();
    	
    	//String sql = String.format("INSERT INTO \"myStore\".products(\"PRODUCT_NAME\", \"DEVELOPER\", \"PUBLISHER\", \"PLATFORM\", \"DESCRIPTION\", \"PRICE\")"
		//		+ " VALUES('%s', '%s', %s, %s, %s, %f)", product.getName(), product.getDeveloper(), product.getPublisher(), product.getPlatform(), product.getDescription(), product.getPrice());
		
    	PreparedStatement sql = conn.prepareStatement("INSERT INTO \"myStore\".products(\"PRODUCT_NAME\", \"DEVELOPER\", \"PUBLISHER\", \"PLATFORM\", \"DESCRIPTION\", \"PRICE\") VALUES (?, ?, ?, ?, ?, ?);");
		
    	
    	try {
			//connect to database
			//conn = DriverManager.getConnection(url, username, password);
			
			//exeute sql query
			//Statement stmt = conn.createStatement();
			//stmt.executeUpdate(sql);
    		
    		sql.executeUpdate();
    		sql.close();
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
	}
    
    //gets all products from product table
    public List<Order> getAllOrders() throws SQLException{
    	//get connection to db
    	Connection conn = getConnection();
    	
		//Select sql statement
    	String sql = "SELECT * FROM \"myStore\".products ORDER BY \"ID\" ASC ";
    	
		//create a list of products
    	List<Order> orders = new ArrayList<Order>();
    	
    	try {
			//exeute sql query
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			//populate the list with data from the query
			while(rs.next()) {
				orders.add(new Order(rs.getString("ORDER_NO"));
			}
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		return orders;
    }
    
    //delete a row from products table by id
    public void removeProduct(int id) throws SQLException{
       	//get connection to db
    	Connection conn = getConnection();
    	
		//Select sql statement
    	PreparedStatement sql = conn.prepareStatement("DELETE FROM \"myStore\".products WHERE \"ID\" IN (?);");
    	
    	sql.setInt(1, id);
    	
    	
    	try {
			//exeute sql query
    		sql.executeUpdate();
    		sql.close();
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
    }
    
    //delete a row from products table by id
    public void updateProduct(int id, Product product) throws SQLException{
       	//get connection to db
    	Connection conn = getConnection();
    	
		//update sql statement
    	PreparedStatement sql = conn.prepareStatement("UPDATE \"myStore\".products SET \"PRODUCT_NAME\"=?, \"DEVELOPER\"=?, \"PUBLISHER\"=?, \"PLATFORM\"=?, \"DESCRIPTION\"=?, \"PRICE\"=? WHERE \"ID\" IN (?);");
    	
    	sql.setString(1, product.getName());
    	sql.setString(2, product.getDeveloper());
    	sql.setString(3, product.getPublisher());
    	sql.setString(4, product.getPlatform());
    	sql.setString(5, product.getDescription());
    	sql.setDouble(6, product.getPrice());
    	sql.setInt(7, id);
    	
    	try {
			//exeute sql query
    		sql.executeUpdate();
    		sql.close();
		}
		catch (SQLException e){
			e.printStackTrace();
			System.out.println("Failure!!" + e.getMessage());
		}
		finally 
		{
			if(conn != null) 
			{
				try 
				{
					conn.close();
				}
				catch(SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
    }*/
}
