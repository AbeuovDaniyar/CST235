package beans;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class passage_meta {
public List<passage_meta_data> passage_meta;

public List<passage_meta_data> getPassage_meta() {
	return passage_meta;
}

public void setPassage_meta(List<passage_meta_data> passage_meta) {
	this.passage_meta = passage_meta;
}


}
