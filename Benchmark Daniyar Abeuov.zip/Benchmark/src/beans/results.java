package beans;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class results {
private List<result> resultList;

@XmlElement(name = "results")
public List<result> getResultList() {
	return resultList;
}

public void setResultList(List<result> resultList) {
	this.resultList = resultList;
}

}
