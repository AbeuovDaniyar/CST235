package beans;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class result {
	
public String reference = "";
public String content = "";

public result(String reference, String content) {
	this.reference = reference;
	this.content = content;
}

public result() {
	super();
}
@XmlElement(name = "reference")
public String getReference() {
	return reference;
}

public void setReference(String reference) {
	this.reference = reference;
}

@XmlElement(name = "content")
public String getContent() {
	return content;
}

public void setContent(String content) {
	this.content = content;
}


}
