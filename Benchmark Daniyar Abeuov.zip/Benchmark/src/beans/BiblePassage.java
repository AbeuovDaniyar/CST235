package beans;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@ManagedBean
@ViewScoped
public class BiblePassage {
	public String query;
	public String canonical;
	public String[][] parsed;
	public List<passage_meta_data> passage_meta;
	public List<String> passages;
	
	public BiblePassage(String query, String canonical, String[][] parsed, List<passage_meta_data> passage_meta,
			List<String> passages) {
		this.query = query;
		this.canonical = canonical;
		this.parsed = parsed;
		this.passage_meta = passage_meta;
		this.passages = passages;
	}
	
	public BiblePassage() {}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getCanonical() {
		return canonical;
	}

	public void setCanonical(String canonical) {
		this.canonical = canonical;
	}

	public String[][] getParsed() {
		return parsed;
	}

	public void setParsed(String[][] parsed) {
		this.parsed = parsed;
	}

	public List<passage_meta_data> getPassage_meta() {
		return passage_meta;
	}

	public void setPassage_meta(List<passage_meta_data> passage_meta) {
		this.passage_meta = passage_meta;
	}

	public List<String> getPassages() {
		return passages;
	}

	public void setPassages(List<String> passages) {
		this.passages = passages;
	}
	
	
}
