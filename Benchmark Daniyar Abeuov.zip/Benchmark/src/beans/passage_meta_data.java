package beans;

import java.util.List;

public class passage_meta_data {
	public String canonical;
	public List<String> chapter_start;
	public List<String> chapter_end;
	public String prev_verse;
	public String next_verse;
	public List<String> prev_chapter;
	public List<String> next_chapter;
	
	public passage_meta_data(String canonical, List<String> chapter_start, List<String> chapter_end, String prev_verse,
			String next_verse, List<String> prev_chapter, List<String> next_chapter) {
		this.canonical = canonical;
		this.chapter_start = chapter_start;
		this.chapter_end = chapter_end;
		this.prev_verse = prev_verse;
		this.next_verse = next_verse;
		this.prev_chapter = prev_chapter;
		this.next_chapter = next_chapter;
	}
	
	public passage_meta_data() {}

	public String getCanonical() {
		return canonical;
	}

	public void setCanonical(String canonical) {
		this.canonical = canonical;
	}

	public List<String> getChapter_start() {
		return chapter_start;
	}

	public void setChapter_start(List<String> chapter_start) {
		this.chapter_start = chapter_start;
	}

	public List<String> getChapter_end() {
		return chapter_end;
	}

	public void setChapter_end(List<String> chapter_end) {
		this.chapter_end = chapter_end;
	}

	public String getPrev_verse() {
		return prev_verse;
	}

	public void setPrev_verse(String prev_verse) {
		this.prev_verse = prev_verse;
	}

	public String getNext_verse() {
		return next_verse;
	}

	public void setNext_verse(String next_verse) {
		this.next_verse = next_verse;
	}

	public List<String> getPrev_chapter() {
		return prev_chapter;
	}

	public void setPrev_chapter(List<String> prev_chapter) {
		this.prev_chapter = prev_chapter;
	}

	public List<String> getNext_chapter() {
		return next_chapter;
	}

	public void setNext_chapter(List<String> next_chapter) {
		this.next_chapter = next_chapter;
	}
	
}
