package beans;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@ManagedBean
@ViewScoped
public class Bible {

	public String page = "";
	public List<result> results;
	public String total_results = "";
	public String total_pages = "";
	public String errors = "";
	
	
	public Bible(String page, List<result> results, String total_results, String total_pages, String errors) {
		this.page = page;
		this.total_results = total_results;
		this.results = results;
		this.total_pages = total_pages;
		this.errors = errors;
	}
	
	public Bible() {
		super();
	}
	
	@XmlElement(name = "errors")
	public String getErrors() {
		return errors;
	}

	public void setErrors(String errors) {
		this.errors = errors;
	}

	@XmlElement(name = "page")
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	@XmlElement(name = "total_results")
	public String getTotal_results() {
		return total_results;
	}
	
	@XmlElement(name = "results")
	public List<result> getResults() {
		return results;
	}
	public void setResults(List<result> results) {
		this.results = results;
	}
	
	@XmlElement(name = "total_pages")
	public String getTotal_pages() {
		return total_pages;
	}

	public void setTotal_pages(String total_pages) {
		this.total_pages = total_pages;
	}

	public void setTotal_results(String total_results) {
		this.total_results = total_results;
	}
	
	
}
